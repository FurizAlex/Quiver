#include "blueHats.h"

#define PBUF (PATH_MAX * 2 + 2)

static int skipName(const char* n) {
	return n[0] == '.'
		|| strcmp(n, "node_modules") == 0
		|| strcmp(n, "__pycache__") == 0
		|| strcmp(n, LOCKFILE) == 0;
}

static int addDir(struct archive* a, const char* root, const char* rel) {
	char dirPath[PBUF];
	if (rel[0])
		snprintf(dirPath, sizeof(dirPath), "%s/%s", root, rel);
	else
		snprintf(dirPath, sizeof(dirPath), "%s", root);

	DIR* dir = opendir(dirPath);
	if (!dir)
		return -1;

	struct dirent* entry;
	while ((entry = readdir(dir)) != NULL) {
		if (skipName(entry->d_name))
			continue;

		char relPath[PBUF], fullPath[PBUF * 2];
		if (rel[0])
			snprintf(relPath, sizeof(relPath), "%s/%s", rel, entry->d_name);
		else
			snprintf(relPath, sizeof(relPath), "%s", entry->d_name);
		snprintf(fullPath, sizeof(fullPath), "%s/%s", root, relPath);

		struct stat st;
		if (lstat(fullPath, &st) != 0)
			continue;
		if (S_ISDIR(st.st_mode)) {
			if (addDir(a, root, relPath) != 0) {
				closedir(dir);
				return -1;
			}
			continue;
		}
		if (!S_ISREG(st.st_mode))
			continue;

		FILE* f = fopen(fullPath, "rb");
		if (!f) {
			fprintf(stderr, "Cannot read %s\n", fullPath);
			closedir(dir);
			return -1;
		}

		struct archive_entry* ae = archive_entry_new();
		archive_entry_set_pathname(ae, relPath);
		archive_entry_set_size(ae, st.st_size);
		archive_entry_set_filetype(ae, AE_IFREG);
		archive_entry_set_perm(ae, (st.st_mode & 0100) ? 0755 : 0644);
		int rc = archive_write_header(a, ae);
		archive_entry_free(ae);
		if (rc != ARCHIVE_OK) {
			fprintf(stderr, "Archive error: %s\n", archive_error_string(a));
			fclose(f);
			closedir(dir);
			return -1;
		}

		char buffer[8192];
		size_t num;
		while ((num = fread(buffer, 1, sizeof(buffer), f)) > 0) {
			if (archive_write_data(a, buffer, num) < 0) {
				fprintf(stderr, "Archive error: %s\n", archive_error_string(a));
				fclose(f);
				closedir(dir);
				return -1;
			}
		}
		fclose(f);
	}
	closedir(dir);
	return 0;
}

int packTarball(const char* sourceDir, const char* outPath) {
	struct archive* a = archive_write_new();
	archive_write_add_filter_gzip(a);
	archive_write_set_format_pax_restricted(a);
	if (archive_write_open_filename(a, outPath) != ARCHIVE_OK) {
		fprintf(stderr, "Cannot create %s: %s\n", outPath, archive_error_string(a));
		archive_write_free(a);
		return -1;
	}
	int rc = addDir(a, sourceDir, "");
	if (archive_write_close(a) != ARCHIVE_OK)
		rc = -1;
	archive_write_free(a);
	return rc;
}

/* Reject absolute paths and any ".." component. */
static int safeEntryPath(const char* p) {
	if (p[0] == '/')
		return 0;
	for (const char* s = p; *s; ) {
		const char* slash = strchr(s, '/');
		size_t len = slash ? (size_t)(slash - s) : strlen(s);
		if (len == 2 && s[0] == '.' && s[1] == '.')
			return 0;
		if (!slash)
			break;
		s = slash + 1;
	}
	return 1;
}

static int copyData(struct archive* in, struct archive* out) {
	const void*	buffer;
	size_t		size;
	la_int64_t	offset;
	int			r;

	while ((r = archive_read_data_block(in, &buffer, &size, &offset)) == ARCHIVE_OK) {
		if (archive_write_data_block(out, buffer, size, offset) != ARCHIVE_OK)
			return -1;
	}
	return r == ARCHIVE_EOF ? 0 : -1;
}

int unpackTarball(const char* tarballPath, const char* outDir) {
	if (mkdirp(outDir) != 0)
		return -1;

	struct archive* in = archive_read_new();
	archive_read_support_format_tar(in);
	archive_read_support_filter_gzip(in);
	if (archive_read_open_filename(in, tarballPath, 10240) != ARCHIVE_OK) {
		fprintf(stderr, "Cannot open archive: %s\n", archive_error_string(in));
		archive_read_free(in);
		return -1;
	}

	struct archive* out = archive_write_disk_new();
	archive_write_disk_set_options(out, ARCHIVE_EXTRACT_TIME
		| ARCHIVE_EXTRACT_SECURE_NODOTDOT
		| ARCHIVE_EXTRACT_SECURE_SYMLINKS
		| ARCHIVE_EXTRACT_SECURE_NOABSOLUTEPATHS);

	int rc = 0, r;
	struct archive_entry* entry;
	while ((r = archive_read_next_header(in, &entry)) == ARCHIVE_OK) {
		const char* name = archive_entry_pathname(entry);
		if (!name || !safeEntryPath(name)) {
			fprintf(stderr, "Refusing unsafe path in archive: %s\n", name ? name : "(null)");
			rc = -1;
			break;
		}
		mode_t type = archive_entry_filetype(entry);
		if (type != AE_IFREG && type != AE_IFDIR)
			continue;	/* no symlinks, devices, etc. */

		char outPath[PBUF];
		int n = snprintf(outPath, sizeof(outPath), "%s/%s", outDir, name);
		if (n < 0 || (size_t)n >= sizeof(outPath)) {
			rc = -1;
			break;
		}
		archive_entry_set_pathname(entry, outPath);

		if (archive_write_header(out, entry) != ARCHIVE_OK) {
			fprintf(stderr, "Extract error: %s\n", archive_error_string(out));
			rc = -1;
			break;
		}
		if (archive_entry_size(entry) > 0 && copyData(in, out) != 0) {
			fprintf(stderr, "Extract error: %s\n", archive_error_string(in));
			rc = -1;
			break;
		}
		archive_write_finish_entry(out);
	}
	if (rc == 0 && r != ARCHIVE_EOF) {
		fprintf(stderr, "Archive error: %s\n", archive_error_string(in));
		rc = -1;
	}
	archive_write_free(out);
	archive_read_free(in);
	return rc;
}