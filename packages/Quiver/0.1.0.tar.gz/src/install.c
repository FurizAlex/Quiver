#include "blueHats.h"

/* Lock file: a list of [[package]] blocks with name/version. */
static int parseLock(const char* path, Dependency* deps) {
	FILE* f = fopen(path, "r");
	char buf[512];
	int count = 0;
	Dependency* cur = NULL;

	if (!f)
		return -1;
	while (fgets(buf, sizeof(buf), f)) {
		char* line = trimStr(buf);
		if (strcmp(line, "[[package]]") == 0) {
			if (count >= MAX_DEPS)
				die("%s has too many packages", path);
			cur = &deps[count++];
			cur->name[0] = cur->version[0] = '\0';
			continue;
		}
		char *key, *val;
		if (cur && parseKeyValue(line, &key, &val)) {
			if (strcmp(key, "name") == 0)
				copyStr(cur->name, NAME_LEN, val);
			else if (strcmp(key, "version") == 0)
				copyStr(cur->version, VER_LEN, val);
		}
	}
	fclose(f);
	return count;
}

static void writeLock(const Dependency* deps, int count) {
	FILE* f = fopen(LOCKFILE, "w");
	if (!f)
		die("Could not write %s", LOCKFILE);
	for (int i = 0; i < count; i++) {
		fprintf(f, "[[package]]\n");
		fprintf(f, "name = \"%s\"\n", deps[i].name);
		fprintf(f, "version = \"%s\"\n\n", deps[i].version);
	}
	fclose(f);
}

/* Pick the highest version in the index that satisfies the constraint. */
static void resolveOne(cJSON* index, Dependency* dep) {
	cJSON* versions = cJSON_GetObjectItemCaseSensitive(index, dep->name);
	if (!cJSON_IsArray(versions))
		die("Package not found: %s", dep->name);

	char best[VER_LEN] = {0};
	int found = 0;
	cJSON* ver;
	cJSON_ArrayForEach(ver, versions) {
		if (!cJSON_IsString(ver) || !isValidVersion(ver->valuestring))
			continue;
		if (!versionSatisfies(dep->version, ver->valuestring))
			continue;
		if (!found || versionGT(ver->valuestring, best)) {
			copyStr(best, sizeof(best), ver->valuestring);
			found = 1;
		}
	}
	if (!found)
		die("No matching version for %s@%s", dep->name, dep->version);
	printf("Resolved %s -> %s\n", dep->name, best);
	copyStr(dep->version, VER_LEN, best);
}

static void installPackage(const char* registry, const Dependency* dep) {
	char url[512], metaUrl[512], outDir[256];
	char tmpPath[] = "/tmp/bluehats-XXXXXX";

	printf("Installing %s@%s...\n", dep->name, dep->version);
	sfmt(url, sizeof(url), "%s/packages/%s/%s.tar.gz", registry, dep->name, dep->version);
	sfmt(metaUrl, sizeof(metaUrl), "%s/packages/%s/%s.json", registry, dep->name, dep->version);
	sfmt(outDir, sizeof(outDir), ".bluehats/%s", dep->name);

	Buffer meta;
	if (fetchURL(metaUrl, &meta) != 0)
		die("Could not fetch metadata for %s@%s", dep->name, dep->version);
	cJSON* json = cJSON_Parse(meta.data);
	free(meta.data);
	cJSON* sum = cJSON_GetObjectItemCaseSensitive(json, "checksum");
	if (!cJSON_IsString(sum))
		die("Metadata for %s@%s has no checksum", dep->name, dep->version);

	int fd = mkstemp(tmpPath);
	if (fd < 0)
		die("Could not create temporary file");
	close(fd);

	if (downloadFile(url, tmpPath) != 0) {
		unlink(tmpPath);
		die("Could not download %s@%s", dep->name, dep->version);
	}
	char* actual = sha256File(tmpPath);
	if (!actual || strcmp(actual, sum->valuestring) != 0) {
		unlink(tmpPath);
		die("Checksum mismatch for %s@%s!", dep->name, dep->version);
	}
	free(actual);
	cJSON_Delete(json);

	if (unpackTarball(tmpPath, outDir) != 0) {
		unlink(tmpPath);
		die("Could not unpack %s@%s", dep->name, dep->version);
	}
	unlink(tmpPath);
	printf(" OK %s@%s\n", dep->name, dep->version);
}

void install(const char* registry) {
	Dependency deps[MAX_DEPS], locked[MAX_DEPS];
	int need[MAX_DEPS];
	int count = 0, anyNeed = 0;

	if (parseToml(MANIFEST, deps, &count) != 0)
		die("Could not read %s (run 'bluehats init' first)", MANIFEST);
	if (count == 0) {
		printf("No dependencies to install.\n");
		return;
	}

	/* Reuse a locked version when it still satisfies the manifest. */
	int lockedCount = parseLock(LOCKFILE, locked);
	if (lockedCount < 0)
		lockedCount = 0;
	for (int i = 0; i < count; i++) {
		need[i] = 1;
		for (int j = 0; j < lockedCount; j++) {
			if (strcmp(deps[i].name, locked[j].name) == 0
				&& isValidVersion(locked[j].version)
				&& versionSatisfies(deps[i].version, locked[j].version)) {
				copyStr(deps[i].version, VER_LEN, locked[j].version);
				need[i] = 0;
				break;
			}
		}
		anyNeed |= need[i];
	}

	if (anyNeed) {
		char indexUrl[512];
		Buffer indexBuffer;
		sfmt(indexUrl, sizeof(indexUrl), "%s/index.json", registry);
		if (fetchURL(indexUrl, &indexBuffer) != 0)
			die("Could not fetch registry index");
		cJSON* index = cJSON_Parse(indexBuffer.data);
		free(indexBuffer.data);
		if (!index)
			die("Registry index.json is not valid JSON");
		for (int i = 0; i < count; i++)
			if (need[i])
				resolveOne(index, &deps[i]);
		cJSON_Delete(index);
	}
	writeLock(deps, count);

	for (int i = 0; i < count; i++)
		installPackage(registry, &deps[i]);
}