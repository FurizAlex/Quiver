#include "blueHats.h"

static size_t WriteCb(void* pointer, size_t size, size_t nmemb, void* userdata) {
	Buffer* buffer = userdata;
	size_t add = size * nmemb;
	char* grown = realloc(buffer->data, buffer->size + add + 1);

	if (!grown)
		return 0;
	buffer->data = grown;
	memcpy(buffer->data + buffer->size, pointer, add);
	buffer->size += add;
	buffer->data[buffer->size] = '\0';
	return add;
}

/* Returns 0 on success (HTTP 2xx / file:// ok), -1 otherwise. Caller frees out->data. */
int fetchURL(const char* url, Buffer* out) {
	out->size = 0;
	out->data = malloc(1);
	if (!out->data)
		return -1;
	out->data[0] = '\0';

	CURL* curl = curl_easy_init();
	if (!curl) {
		free(out->data);
		out->data = NULL;
		return -1;
	}
	curl_easy_setopt(curl, CURLOPT_URL, url);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCb);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, out);
	curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
	curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);
	curl_easy_setopt(curl, CURLOPT_USERAGENT, "bluehats");

	CURLcode res = curl_easy_perform(curl);
	curl_easy_cleanup(curl);
	if (res != CURLE_OK) {
		fprintf(stderr, "Request failed: %s (%s)\n", curl_easy_strerror(res), url);
		free(out->data);
		out->data = NULL;
		out->size = 0;
		return -1;
	}
	return 0;
}

int downloadFile(const char* url, const char* outPath) {
	Buffer buffer;

	if (fetchURL(url, &buffer) != 0)
		return -1;
	int rc = writeFile(outPath, buffer.data, buffer.size);
	free(buffer.data);
	return rc;
}

/* Returns a malloc'd 64-char hex string, or NULL on failure. */
char* sha256File(const char* path) {
	FILE* f = fopen(path, "rb");
	if (!f)
		return NULL;

	EVP_MD_CTX* ctx = EVP_MD_CTX_new();
	if (!ctx || EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1) {
		EVP_MD_CTX_free(ctx);
		fclose(f);
		return NULL;
	}

	unsigned char buffer[4096];
	size_t num;
	while ((num = fread(buffer, 1, sizeof(buffer), f)) > 0)
		EVP_DigestUpdate(ctx, buffer, num);
	int readFailed = ferror(f);
	fclose(f);

	unsigned char hash[EVP_MAX_MD_SIZE];
	unsigned int hashLen = 0;
	int ok = EVP_DigestFinal_ex(ctx, hash, &hashLen) == 1;
	EVP_MD_CTX_free(ctx);
	if (!ok || readFailed || hashLen != 32)
		return NULL;

	char* hex = malloc(65);
	if (!hex)
		return NULL;
	for (unsigned int i = 0; i < 32; i++)
		sprintf(hex + i * 2, "%02x", hash[i]);
	hex[64] = '\0';
	return hex;
}