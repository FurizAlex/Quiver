#include "blueHats.h"

/* Replace with the URL of your hosted registry (GitHub Pages, Cloudflare Pages, ...).
 * Override at runtime with BLUEHATS_REGISTRY. file:///path/to/registry also works. */
#define DEFAULT_REGISTRY "https://YOUR-USER.github.io/bluehats-registry"

void printUsage(void) {
	printf("Blue Hats - FOSP Package Manager\n\n");
	printf("usage:\n");
	printf("  bluehats init                   create a new %s\n", MANIFEST);
	printf("  bluehats install                install all dependencies\n");
	printf("  bluehats add <package>          add a dependency and install it\n");
	printf("  bluehats publish [registry-dir] add this package to a local registry folder\n\n");
	printf("environment:\n");
	printf("  BLUEHATS_REGISTRY      registry URL used by install/add\n");
	printf("  BLUEHATS_REGISTRY_DIR  registry folder used by publish\n");
}

static void readLine(const char* prompt, char* buf, size_t size) {
	printf("%s", prompt);
	fflush(stdout);
	if (!fgets(buf, size, stdin))
		die("input cancelled");
	buf[strcspn(buf, "\n")] = '\0';
}

void init(void) {
	char name[NAME_LEN], version[VER_LEN], author[64];

	if (access(MANIFEST, F_OK) == 0)
		die("%s already exists", MANIFEST);

	readLine("package name: ", name, sizeof(name));
	readLine("version (0.1.0): ", version, sizeof(version));
	readLine("author: ", author, sizeof(author));

	if (version[0] == '\0')
		copyStr(version, sizeof(version), "0.1.0");
	if (!isValidName(name))
		die("package names may only contain letters, digits, '.', '_' and '-'");
	if (!isValidVersion(version))
		die("version must look like 1.2.3");
	if (strchr(author, '"'))
		die("author may not contain a double quote");

	FILE* f = fopen(MANIFEST, "w");
	if (!f)
		die("failed to create %s", MANIFEST);
	fprintf(f, "[package]\n");
	fprintf(f, "name = \"%s\"\n", name);
	fprintf(f, "version = \"%s\"\n", version);
	fprintf(f, "author = \"%s\"\n", author);
	fprintf(f, "entry = \"main\"\n\n");
	fprintf(f, "[dependencies]\n");
	fclose(f);
	printf("Created %s\n", MANIFEST);
}

int main(int argc, char** argv) {
	if (argc < 2) {
		printUsage();
		return 1;
	}
	curl_global_init(CURL_GLOBAL_DEFAULT);

	const char* registry = getenv("BLUEHATS_REGISTRY");
	if (!registry || !*registry)
		registry = DEFAULT_REGISTRY;

	const char* cmd = argv[1];
	if (strcmp(cmd, "init") == 0 && argc == 2)
		init();
	else if (strcmp(cmd, "install") == 0 && argc == 2)
		install(registry);
	else if (strcmp(cmd, "add") == 0 && argc == 3)
		add(registry, argv[2]);
	else if (strcmp(cmd, "publish") == 0 && argc <= 3) {
		const char* dir = argc == 3 ? argv[2] : getenv("BLUEHATS_REGISTRY_DIR");
		if (!dir || !*dir)
			die("no registry folder given. Usage: bluehats publish <registry-dir>");
		publish(dir);
	} else {
		printUsage();
		curl_global_cleanup();
		return 1;
	}
	curl_global_cleanup();
	return 0;
}