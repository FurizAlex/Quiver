#include "blueHats.h"

int error(const char* message, int errorCode) {
	fprintf(stderr, "Blue Hats Error: %s\n", message ? message : "(unknown)");
	return errorCode;
}

void die(const char* fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	fprintf(stderr, "Blue Hats Error: ");
	vfprintf(stderr, fmt, ap);
	fprintf(stderr, "\n");
	va_end(ap);
	exit(1);
}

/* snprintf that dies instead of silently truncating */
void sfmt(char* dst, size_t size, const char* fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(dst, size, fmt, ap);
	va_end(ap);
	if (n < 0 || (size_t)n >= size)
		die("path or URL too long");
}

/* strncpy that always terminates */
void copyStr(char* dst, size_t size, const char* src) {
	strncpy(dst, src, size - 1);
	dst[size - 1] = '\0';
}

void* xrealloc(void* ptr, size_t size) {
	void* p = realloc(ptr, size);
	if (!p)
		die("out of memory");
	return p;
}

char* xstrdup(const char* s) {
	char* p = strdup(s);
	if (!p)
		die("out of memory");
	return p;
}

/* Names end up in file paths and URLs, so keep them boring. */
int isValidName(const char* s) {
	size_t len = strlen(s);

	if (len == 0 || len >= NAME_LEN)
		return 0;
	if (strcmp(s, ".") == 0 || strcmp(s, "..") == 0)
		return 0;
	for (size_t i = 0; i < len; i++) {
		unsigned char c = (unsigned char)s[i];
		if (!isalnum(c) && c != '.' && c != '_' && c != '-')
			return 0;
	}
	return 1;
}

/* Exactly MAJOR.MINOR.PATCH */
int isValidVersion(const char* s) {
	int a, b, c, n = 0;

	if (strlen(s) >= VER_LEN)
		return 0;
	if (sscanf(s, "%d.%d.%d%n", &a, &b, &c, &n) != 3)
		return 0;
	return s[n] == '\0' && a >= 0 && b >= 0 && c >= 0;
}

int mkdirp(const char* path) {
	char tmp[PATH_MAX];
	size_t len = strlen(path);

	if (len == 0 || len >= sizeof(tmp))
		return -1;
	memcpy(tmp, path, len + 1);
	for (size_t i = 1; i < len; i++) {
		if (tmp[i] == '/') {
			tmp[i] = '\0';
			if (mkdir(tmp, 0755) != 0 && errno != EEXIST)
				return -1;
			tmp[i] = '/';
		}
	}
	if (mkdir(tmp, 0755) != 0 && errno != EEXIST)
		return -1;
	return 0;
}

char* readFile(const char* path, size_t* size) {
	FILE* f = fopen(path, "rb");
	if (!f)
		return NULL;
	if (fseek(f, 0, SEEK_END) != 0) {
		fclose(f);
		return NULL;
	}
	long len = ftell(f);
	if (len < 0) {
		fclose(f);
		return NULL;
	}
	rewind(f);
	char* data = malloc((size_t)len + 1);
	if (!data) {
		fclose(f);
		return NULL;
	}
	size_t got = fread(data, 1, (size_t)len, f);
	fclose(f);
	data[got] = '\0';
	if (size)
		*size = got;
	return data;
}

/* Write to <path>.tmp then rename, so a crash never leaves a half-written file. */
int writeFile(const char* path, const char* data, size_t len) {
	char tmp[PATH_MAX];
	int n = snprintf(tmp, sizeof(tmp), "%s.tmp", path);
	if (n < 0 || (size_t)n >= sizeof(tmp))
		return -1;

	FILE* f = fopen(tmp, "wb");
	if (!f)
		return -1;
	if (fwrite(data, 1, len, f) != len) {
		fclose(f);
		unlink(tmp);
		return -1;
	}
	if (fclose(f) != 0) {
		unlink(tmp);
		return -1;
	}
	if (rename(tmp, path) != 0) {
		unlink(tmp);
		return -1;
	}
	return 0;
}

int copyFile(const char* src, const char* dst) {
	size_t size = 0;
	char* data = readFile(src, &size);
	if (!data)
		return -1;
	int rc = writeFile(dst, data, size);
	free(data);
	return rc;
}