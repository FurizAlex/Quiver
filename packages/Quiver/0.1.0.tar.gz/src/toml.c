#include "blueHats.h"

/* Trims in place and returns a pointer into the same buffer. Handles tabs. */
char* trimStr(char* s) {
	while (*s && isspace((unsigned char)*s))
		s++;
	char* end = s + strlen(s);
	while (end > s && isspace((unsigned char)end[-1]))
		end--;
	*end = '\0';
	return s;
}

/* Splits `key = "value"` in place. Returns 1 on success. */
int parseKeyValue(char* line, char** key, char** val) {
	char* eq = strchr(line, '=');
	if (!eq)
		return 0;
	*eq = '\0';
	*key = trimStr(line);
	char* v = trimStr(eq + 1);
	size_t n = strlen(v);
	if (n >= 2 && v[0] == '"' && v[n - 1] == '"') {
		v[n - 1] = '\0';
		v++;
	}
	*val = v;
	return **key != '\0';
}

typedef int (*KVCallback)(const char* key, const char* val, void* ctx);

/* Calls fn for every key = value line inside [section]. -1 if file can't be opened. */
static int walkSection(const char* path, const char* section, KVCallback fn, void* ctx) {
	FILE* f = fopen(path, "r");
	char buf[512];
	int inSection = 0;

	if (!f)
		return -1;
	while (fgets(buf, sizeof(buf), f)) {
		char* line = trimStr(buf);
		if (line[0] == '\0' || line[0] == '#')
			continue;
		if (line[0] == '[') {
			inSection = strcmp(line, section) == 0;
			continue;
		}
		char *key, *val;
		if (inSection && parseKeyValue(line, &key, &val))
			fn(key, val, ctx);
	}
	fclose(f);
	return 0;
}

typedef struct {
	Dependency*	deps;
	int*		count;
}	DepCtx;

static int depCallback(const char* key, const char* val, void* ctx) {
	DepCtx* d = ctx;

	if (*d->count >= MAX_DEPS)
		die("too many dependencies (max %d)", MAX_DEPS);
	if (!isValidName(key))
		die("invalid dependency name in %s: '%s'", MANIFEST, key);
	if (*val == '\0' || strlen(val) >= VER_LEN)
		die("invalid version constraint for '%s'", key);
	copyStr(d->deps[*d->count].name, NAME_LEN, key);
	copyStr(d->deps[*d->count].version, VER_LEN, val);
	(*d->count)++;
	return 0;
}

int parseToml(const char* path, Dependency* deps, int* count) {
	DepCtx ctx = { deps, count };
	*count = 0;
	return walkSection(path, "[dependencies]", depCallback, &ctx);
}

typedef struct {
	char*	name;
	char*	version;
}	InfoCtx;

static int infoCallback(const char* key, const char* val, void* ctx) {
	InfoCtx* info = ctx;

	if (strcmp(key, "name") == 0) {
		if (strlen(val) >= NAME_LEN)
			die("package name too long");
		copyStr(info->name, NAME_LEN, val);
	} else if (strcmp(key, "version") == 0) {
		if (strlen(val) >= VER_LEN)
			die("package version too long");
		copyStr(info->version, VER_LEN, val);
	}
	return 0;
}

/* name must hold NAME_LEN bytes, version VER_LEN bytes */
int parsePackageInfo(const char* path, char* name, char* version) {
	InfoCtx ctx = { name, version };
	return walkSection(path, "[package]", infoCallback, &ctx);
}

/* Adds (or updates) `name = "^version"` inside [dependencies], creating the
 * section if needed, and leaves the rest of the file untouched. */
void addDependency(const char* path, const char* name, const char* version) {
	char* text = readFile(path, NULL);
	if (!text)
		die("Could not read %s (run 'bluehats init' first)", path);

	int cap = 64, cnt = 0;
	char** lines = xrealloc(NULL, cap * sizeof(*lines));
	for (char* p = text; *p; ) {
		char* nl = strchr(p, '\n');
		size_t len = nl ? (size_t)(nl - p) : strlen(p);
		if (cnt + 1 >= cap) {
			cap *= 2;
			lines = xrealloc(lines, cap * sizeof(*lines));
		}
		lines[cnt] = xrealloc(NULL, len + 1);
		memcpy(lines[cnt], p, len);
		lines[cnt][len] = '\0';
		cnt++;
		p += len + (nl ? 1 : 0);
	}
	free(text);
	if (cnt + 4 >= cap) {
		cap = cnt + 8;
		lines = xrealloc(lines, cap * sizeof(*lines));
	}

	char newLine[256];
	sfmt(newLine, sizeof(newLine), "%s = \"^%s\"", name, version);

	int depStart = -1, depEnd = cnt, replaced = 0;
	for (int i = 0; i < cnt; i++) {
		char* copy = xstrdup(lines[i]);
		char* t = trimStr(copy);

		if (depStart < 0) {
			if (strcmp(t, "[dependencies]") == 0)
				depStart = i;
		} else if (t[0] == '[') {
			depEnd = i;
			free(copy);
			break;
		} else if (t[0] != '#') {
			char *k, *v;
			if (parseKeyValue(t, &k, &v) && strcmp(k, name) == 0) {
				free(lines[i]);
				lines[i] = xstrdup(newLine);
				replaced = 1;
			}
		}
		free(copy);
	}

	if (!replaced) {
		if (depStart < 0) {
			if (cnt > 0 && lines[cnt - 1][0] != '\0')
				lines[cnt++] = xstrdup("");
			lines[cnt++] = xstrdup("[dependencies]");
			lines[cnt++] = xstrdup(newLine);
		} else {
			int at = depEnd;
			/* insert after the last non-blank line of the section */
			while (at - 1 > depStart && lines[at - 1][0] == '\0')
				at--;
			memmove(&lines[at + 1], &lines[at], (cnt - at) * sizeof(*lines));
			lines[at] = xstrdup(newLine);
			cnt++;
		}
	}

	char* out = NULL;
	size_t outLen = 0;
	FILE* mem = open_memstream(&out, &outLen);
	if (!mem)
		die("out of memory");
	for (int i = 0; i < cnt; i++) {
		fprintf(mem, "%s\n", lines[i]);
		free(lines[i]);
	}
	free(lines);
	fclose(mem);

	if (writeFile(path, out, outLen) != 0)
		die("Could not write %s", path);
	free(out);
}