#include "blueHats.h"

void parseVersion(const char* v, int* major, int* minor, int* patch) {
	*major = *minor = *patch = 0;
	while (*v && !isdigit((unsigned char)*v))
		v++;
	sscanf(v, "%d.%d.%d", major, minor, patch);
}

/* Constraint forms: "^1.2.3" (same major), "~1.2.3" (same minor), "1.2.3" (exact) */
int versionSatisfies(const char* constraint, const char* candidate) {
	char	type = '^';
	int		cMaj, cMin, cPat;
	int		vMaj, vMin, vPat;

	if (constraint[0] == '^' || constraint[0] == '~')
		type = constraint[0];
	else if (isdigit((unsigned char)constraint[0]))
		type = '=';
	parseVersion(constraint, &cMaj, &cMin, &cPat);
	parseVersion(candidate, &vMaj, &vMin, &vPat);

	if (type == '=')
		return cMaj == vMaj && cMin == vMin && cPat == vPat;
	if (vMaj != cMaj)
		return 0;
	if (type == '~' && vMin != cMin)
		return 0;
	if (vMin < cMin)
		return 0;
	if (vMin == cMin && vPat < cPat)
		return 0;
	return 1;
}

int versionGT(const char* a, const char* b) {
	int aMaj, aMin, aPat;
	int bMaj, bMin, bPat;

	parseVersion(a, &aMaj, &aMin, &aPat);
	parseVersion(b, &bMaj, &bMin, &bPat);
	if (aMaj != bMaj)
		return aMaj > bMaj;
	if (aMin != bMin)
		return aMin > bMin;
	return aPat > bPat;
}