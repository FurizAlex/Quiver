#include "blueHats.h"

/* The registry directory must not live inside the package being packed,
 * otherwise the tarball would swallow the registry. */
static void checkRegistryOutside(const char* registryDir) {
	char reg[PATH_MAX], cwd[PATH_MAX];

	if (!realpath(registryDir, reg) || !getcwd(cwd, sizeof(cwd)))
		die("Could not resolve registry directory");
	size_t len = strlen(cwd);
	if (strncmp(reg, cwd, len) == 0 && (reg[len] == '/' || reg[len] == '\0'))
		die("Registry directory must be outside the package directory");
}

void publish(const char* registryDir) {
	char name[NAME_LEN] = {0};
	char version[VER_LEN] = {0};

	if (parsePackageInfo(MANIFEST, name, version) != 0)
		die("Could not read %s", MANIFEST);
	if (!isValidName(name))
		die("Invalid or missing package name in %s", MANIFEST);
	if (!isValidVersion(version))
		die("Version in %s must look like 1.2.3", MANIFEST);
	printf("Publishing %s@%s to %s\n", name, version, registryDir);

	if (mkdirp(registryDir) != 0)
		die("Could not create %s", registryDir);
	checkRegistryOutside(registryDir);

	/* Load (or start) the index and refuse to overwrite an existing version. */
	char indexPath[PATH_MAX];
	sfmt(indexPath, sizeof(indexPath), "%s/index.json", registryDir);

	cJSON* index;
	char* text = readFile(indexPath, NULL);
	if (text) {
		index = cJSON_Parse(text);
		free(text);
		if (!cJSON_IsObject(index))
			die("%s is not a valid JSON object", indexPath);
	} else {
		if (errno != ENOENT)
			die("Could not read %s", indexPath);
		index = cJSON_CreateObject();
	}

	cJSON* versions = cJSON_GetObjectItemCaseSensitive(index, name);
	if (versions && !cJSON_IsArray(versions))
		die("index.json entry for %s is malformed", name);
	if (!versions) {
		versions = cJSON_CreateArray();
		cJSON_AddItemToObject(index, name, versions);
	}
	cJSON* v;
	cJSON_ArrayForEach(v, versions) {
		if (cJSON_IsString(v) && strcmp(v->valuestring, version) == 0)
			die("%s@%s is already published. Bump the version in %s (published versions are immutable).",
				name, version, MANIFEST);
	}

	/* Pack to a temp file, hash it, then copy into the registry. */
	char tmpPath[] = "/tmp/bluehats-XXXXXX";
	int fd = mkstemp(tmpPath);
	if (fd < 0)
		die("Could not create temporary file");
	close(fd);

	if (packTarball(".", tmpPath) != 0) {
		unlink(tmpPath);
		die("Could not create tarball");
	}
	char* checksum = sha256File(tmpPath);
	if (!checksum) {
		unlink(tmpPath);
		die("Could not hash tarball");
	}

	char pkgDir[PATH_MAX], tarPath[PATH_MAX], metaPath[PATH_MAX];
	sfmt(pkgDir, sizeof(pkgDir), "%s/packages/%s", registryDir, name);
	sfmt(tarPath, sizeof(tarPath), "%s/%s.tar.gz", pkgDir, version);
	sfmt(metaPath, sizeof(metaPath), "%s/%s.json", pkgDir, version);
	if (mkdirp(pkgDir) != 0)
		die("Could not create %s", pkgDir);
	if (copyFile(tmpPath, tarPath) != 0)
		die("Could not write %s", tarPath);
	unlink(tmpPath);

	cJSON* meta = cJSON_CreateObject();
	cJSON_AddStringToObject(meta, "name", name);
	cJSON_AddStringToObject(meta, "version", version);
	cJSON_AddStringToObject(meta, "checksum", checksum);
	char* metaText = cJSON_Print(meta);
	if (!metaText || writeFile(metaPath, metaText, strlen(metaText)) != 0)
		die("Could not write %s", metaPath);
	free(metaText);
	cJSON_Delete(meta);

	/* Index goes last so it never points at files that don't exist yet. */
	cJSON_AddItemToArray(versions, cJSON_CreateString(version));
	char* indexText = cJSON_Print(index);
	if (!indexText || writeFile(indexPath, indexText, strlen(indexText)) != 0)
		die("Could not write %s", indexPath);
	free(indexText);
	cJSON_Delete(index);
	free(checksum);

	printf("Done! %s@%s written to the registry.\n", name, version);
	printf("Now commit and push the registry to make it live:\n");
	printf("  cd %s && git add -A && git commit -m \"publish %s@%s\" && git push\n",
		registryDir, name, version);
}