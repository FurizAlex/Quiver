#ifndef BLUE_HATS_H
#define BLUE_HATS_H

#define _GNU_SOURCE

#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <limits.h>
#include <sys/stat.h>
#include <curl/curl.h>
#include <archive.h>
#include <archive_entry.h>
#include <openssl/evp.h>
#include <cjson/cJSON.h>

#define MAX_DEPS	64
#define NAME_LEN	64
#define VER_LEN		32

#define MANIFEST	"bluehats.toml"
#define LOCKFILE	"bluehats.lock"

typedef struct {
	char name[NAME_LEN];
	char version[VER_LEN];
}	Dependency;

typedef struct {
	char*	data;
	size_t	size;
}	Buffer;

/* util.c */
int		error(const char* message, int errorCode);
void	die(const char* fmt, ...);
void	sfmt(char* dst, size_t size, const char* fmt, ...);
void	copyStr(char* dst, size_t size, const char* src);
void*	xrealloc(void* ptr, size_t size);
char*	xstrdup(const char* s);
int		isValidName(const char* s);
int		isValidVersion(const char* s);
int		mkdirp(const char* path);
char*	readFile(const char* path, size_t* size);
int		writeFile(const char* path, const char* data, size_t len);
int		copyFile(const char* src, const char* dst);

/* version.c */
void	parseVersion(const char* v, int* major, int* minor, int* patch);
int		versionSatisfies(const char* constraint, const char* candidate);
int		versionGT(const char* a, const char* b);

/* toml.c */
char*	trimStr(char* s);
int		parseKeyValue(char* line, char** key, char** val);
int		parseToml(const char* path, Dependency* deps, int* count);
int		parsePackageInfo(const char* path, char* name, char* version);
void	addDependency(const char* path, const char* name, const char* version);

/* net.c */
int		fetchURL(const char* url, Buffer* out);
int		downloadFile(const char* url, const char* outPath);
char*	sha256File(const char* path);

/* tarball.c */
int		packTarball(const char* sourceDir, const char* outPath);
int		unpackTarball(const char* tarballPath, const char* outDir);

/* commands */
void	install(const char* registry);
void	add(const char* registry, const char* package);
void	publish(const char* registryDir);
void	init(void);
void	printUsage(void);

#endif