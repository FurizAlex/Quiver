#include "blueHats.h"

static const char* latestVersion(cJSON* versions) {
	const char* best = NULL;
	cJSON* ver;

	cJSON_ArrayForEach(ver, versions) {
		if (!cJSON_IsString(ver) || !isValidVersion(ver->valuestring))
			continue;
		if (!best || versionGT(ver->valuestring, best))
			best = ver->valuestring;
	}
	return best;
}

void add(const char* registry, const char* package) {
	char url[512], best[VER_LEN];
	Buffer buffer;

	if (!isValidName(package))
		die("Invalid package name: %s", package);

	sfmt(url, sizeof(url), "%s/index.json", registry);
	if (fetchURL(url, &buffer) != 0)
		die("Could not fetch registry index");
	cJSON* index = cJSON_Parse(buffer.data);
	free(buffer.data);
	if (!index)
		die("Registry index.json is not valid JSON");

	cJSON* versions = cJSON_GetObjectItemCaseSensitive(index, package);
	if (!cJSON_IsArray(versions))
		die("Package not found: %s", package);
	const char* ver = latestVersion(versions);
	if (!ver)
		die("No versions available for %s", package);
	copyStr(best, sizeof(best), ver);
	cJSON_Delete(index);

	addDependency(MANIFEST, package, best);
	printf("Added %s = \"^%s\" to %s\n", package, best, MANIFEST);
	printf("Running install...\n");
	install(registry);
}